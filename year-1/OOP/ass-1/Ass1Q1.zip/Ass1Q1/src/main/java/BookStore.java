//import of package

public class BookStore {
    //the message has been provided for you - do not change this
    private final String message = "The urgent orders are piling up .... time to ship quicker";
    //create the invoices ArrayList<>

    //complete the constructor
    //getter() for invoices list

    //search for an order

    //piling up of orders
}
