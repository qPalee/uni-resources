public class Invoice {
    //attributes


    //complete the constructor


    //complete the getter()

    //complete the totalCost for a shipping order
}
