public class Order {
    //attributes

    public Order(Customer customer, Stock stock) {
        //complete the constructor
    }

    //complete the getters()
    public Customer getCustomer() {
        return null;
    }

    public Stock getStock() {
        return null;
    }
}
