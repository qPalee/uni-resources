import java.time.LocalDate;

public class BookStoreMain {
    public static void main(String[] args) {
        //create a bookStore object and instantiate

        //create a customer who can then buy books

        //customer1 places an order to purchase a book

        //placing the order ****


        //determine the shipping date


        //calculate the shipping cost to send the order



        //create an invoice ****


        //add the invoices to a list so that we can search for an invoice ****

        //a repeat with another customer, order, etc...


        //determine the shipping date


        //calculate the shipping cost to send the order


        //create an invoice


        //add the invoices to a list so that we can search for an invoice


        //search for order

    }
}

