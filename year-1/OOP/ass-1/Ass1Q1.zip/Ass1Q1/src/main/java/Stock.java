public class Stock {
    //attributes

    public Stock(String bookName, String author, double price) {
       //complete the constructor
    }
    //complete the getters()
    public String getBookName() {
        return null;
    }

    public String getAuthor() {
        return null;
    }

    public double getPrice() {
        return 0.00;
    }
}
