public class Customer {
    //attributes

    public Customer(String name, String phone, String emailAddress) { //2 marks
        //complete the constructor
    }

    //complete the getters()
    public String getName() {
        return null;
    }

    public String getPhone() {
        return null;
    }

    public String getEmailAddress() {
        return null;
    }

}
